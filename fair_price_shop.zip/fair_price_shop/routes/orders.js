var express = require('express');
var router = express.Router();
const pool = require('../connection');
const util = require('util');


const getConnection = () => {
  return new Promise((resolve, reject) => {
    pool.getConnection((error, connection) => {
      if (error) {
        reject(error);
      } else {
        resolve(connection);
      }
    });
  });
};

router.get('/', (req, res) => {
  pool.getConnection((error, connection) => {
    if (error) {
      console.error('MySQL connection error:', error);
      res.status(500).json({ error: 'Internal server error' });
      return;
    }
    connection.query('SELECT * FROM orders', (error, results) => {
      connection.release();
      if (error) {
        console.error('MySQL query error:', error);
        res.status(500).json({ error: 'Internal server error' });
      } else if (results.length === 0) {
       res.status(401).json({ error: 'No orders found' });
      } else {
        res.json({ products: results });
      }
    });
  });
});

router.post('/add', async (req,res) =>{
  const customer_id = req.body.customer_id;
  const cart = req.session.cart;
  const product_status = 'In Process';
  // const [productStockResults] = 0;
  if (cart.length === 0) {
    return res.json({ message: "There is no item in the cart" });
  }
  const dbconnection = await getConnection();
  const queryAsync = util.promisify(dbconnection.query).bind(dbconnection);
  // console.log(dbconnection);
      let total = 0;
      const price = [];
      const stock = [];

      for (let i = 0; i < cart.length; i++) {
        const product_id = cart[i].product_id;
        const quantity = cart[i].quantity;

        const [productResults] = await queryAsync('SELECT * FROM `products` left join product_stock on products.id = product_stock.product_id where products.id = ?', [product_id]);
        
        if (productResults.length === 0) {
          return res.status(401).json({ error: 'No product found' });
        }
        if (productResults.stock === 0){
          return res.status(401).json({ error: 'A product is out of stock' });
        }
        const productPrice = productResults.price; 
        price.push(productPrice);
        total += productPrice * quantity;

        var productStock =  productResults.stock;
        // console.log(productStock);
        productStock = productStock - quantity;
        stock.push(productStock);
        // console.log(stock);
        // console.log(productStock - quantity);
      }
      // console.log(stock);
      const orderResults = await queryAsync('INSERT INTO orders (status,customer_id, total) VALUES (?, ?, ?)', [product_status,customer_id, total]);

      if (orderResults.affectedRows === 0) {
        return res.status(401).json({ error: 'There was an error in placing the order' });
      }

      for (let i = 0; i < cart.length; i++) {
        const order_id = orderResults.insertId;
        const product_id = cart[i].product_id;
        const quantity = cart[i].quantity;

        await queryAsync('INSERT INTO order_lines (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)', [order_id, product_id, quantity, price[i]]);
        await queryAsync('UPDATE product_stock set stock = ? where product_id = ?', [stock[i], product_id]);
      }

      req.session.cart = [];
      res.json({ message: "Your order has been successfully placed" });
    
});

router.put('/update/:id', (req, res) => {
  customer_id = req.body.customer_id;
  total = req.body.total;
  id = req.params.id;
  
  pool.getConnection((error, connection) => {
    if (error) {
      console.error('MySQL connection error:', error);
      res.status(500).json({ error: 'Internal server error' });
      return;
    }
    connection.query('UPDATE orders set customer_id = ?, total = ? where id = ?', [customer_id, total], (error, results) => {
      connection.release();
      if (error) {
        console.error('MySQL query error:', error);
        res.status(500).json({ error: 'Internal server error' });
      } else if (results.length === 0) {
       res.status(401).json({ error: 'No order found' });
      } else {
        res.json({ message: "Order has been updated successfully" });
      }
    });
  });
});

router.delete('/delete/:id', (req, res) => {
  id = req.params.id;
  pool.getConnection((error, connection) => {
    if (error) {
      console.error('MySQL connection error:', error);
      res.status(500).json({ error: 'Internal server error' });
      return;
    }
    connection.query('DELETE from orders where id=?', [id], (error, results) => {
      connection.release();
      if (error) {
        console.error('MySQL query error:', error);
        res.status(500).json({ error: 'Internal server error' });
      } else if (results.length === 0) {
       res.status(401).json({ error: 'No orders found' });
      } else {
        res.json({ message: "Order has been deleted successfully" });
      }
    });
  });
});


module.exports = router;