var express = require('express');
var router = express.Router();
const pool = require('../connection');

router.get('/', (req, res) => {
  pool.getConnection((error, connection) => {
    if (error) {
      console.error('MySQL connection error:', error);
      res.status(500).json({ error: 'Internal server error' });
      return;
    }
    connection.query('SELECT * FROM customer_logs', (error, results) => {
      connection.release();
      if (error) {
        console.error('MySQL query error:', error);
        res.status(500).json({ error: 'Internal server error' });
      } else if (results.length === 0) {
       res.status(401).json({ error: 'No customer details found' });
      } else {
        res.json({ products: results });
      }
    });
  });
});

router.post('/add', (req, res) => {
  customer_name = req.body.customer_name;
  customer_email = req.body.customer_email;
  customer_employee_number = req.body.customer_employee_number;
  pool.getConnection((error, connection) => {
    if (error) {
      console.error('MySQL connection error:', error);
      res.status(500).json({ error: 'Internal server error' });
      return;
    }
    connection.query('INSERT INTO customer_logs(name,email,employee_number) VALUES (?,?,?)', [customer_name,customer_email.customer_employee_number], (error, results) => {
      connection.release();
      if (error) {
        console.error('MySQL query error:', error);
        res.status(500).json({ error: 'Internal server error' });
      } else if (results.length === 0) {
       res.status(401).json({ error: 'No customer details found' });
      } else {
        res.json({ message: "Customer detail has been added successfully" });
      }
    });
  });
});

router.put('/update/:id', (req, res) => {
  customer_name = req.body.customer_name;
  customer_email = req.body.customer_email;
  customer_employee_number = req.body.customer_employee_number;
  id = req.params.id;
  
  pool.getConnection((error, connection) => {
    if (error) {
      console.error('MySQL connection error:', error);
      res.status(500).json({ error: 'Internal server error' });
      return;
    }
    connection.query('UPDATE customer_logs set name = ?, email = ?, employee_number = ? where id = ?', [customer_name, customer_email, customer_employee_number], (error, results) => {
      connection.release();
      if (error) {
        console.error('MySQL query error:', error);
        res.status(500).json({ error: 'Internal server error' });
      } else if (results.length === 0) {
       res.status(401).json({ error: 'No customer details found' });
      } else {
        res.json({ message: "Customer details has been updated successfully" });
      }
    });
  });
});

router.delete('/delete/:id', (req, res) => {
  id = req.params.id;
  pool.getConnection((error, connection) => {
    if (error) {
      console.error('MySQL connection error:', error);
      res.status(500).json({ error: 'Internal server error' });
      return;
    }
    connection.query('DELETE from customer_logs where id=?', [id], (error, results) => {
      connection.release();
      if (error) {
        console.error('MySQL query error:', error);
        res.status(500).json({ error: 'Internal server error' });
      } else if (results.length === 0) {
       res.status(401).json({ error: 'No customer detail found' });
      } else {
        res.json({ message: "Customer detail has been deleted successfully" });
      }
    });
  });
});


module.exports = router;