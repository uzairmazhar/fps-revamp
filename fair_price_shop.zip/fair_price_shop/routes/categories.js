var express = require('express');
var router = express.Router();
const pool = require('../connection');

router.get('/', (req, res) => {
  pool.getConnection((error, connection) => {
    if (error) {
      console.error('MySQL connection error:', error);
      res.status(500).json({ error: 'Internal server error' });
      return;
    }
    connection.query('SELECT * FROM categories', (error, results) => {
      connection.release();
      if (error) {
        console.error('MySQL query error:', error);
        res.status(500).json({ error: 'Internal server error' });
      } else if (results.length === 0) {
       res.status(401).json({ error: 'No categories found' });
      } else {
        res.json({ products: results });
      }
    });
  });
});

router.post('/add', (req, res) => {
  category_name = req.body.category_name;
  category_brand = req.body.brand_id;
  pool.getConnection((error, connection) => {
    if (error) {
      console.error('MySQL connection error:', error);
      res.status(500).json({ error: 'Internal server error' });
      return;
    }
    connection.query('INSERT INTO categories(name, brand_id) VALUES (?,?)', [category_name,category_brand], (error, results) => {
      connection.release();
      if (error) {
        console.error('MySQL query error:', error);
        res.status(500).json({ error: 'Internal server error' });
      } else if (results.length === 0) {
       res.status(401).json({ error: 'No categories found' });
      } else {
        res.json({ message: "Category has been added successfully" });
      }
    });
  });
});

router.put('/update/:id', (req, res) => {
  category_name = req.body.category_name;
  category_brand = req.body.brand_id;

  id = req.params.id;
  
  pool.getConnection((error, connection) => {
    if (error) {
      console.error('MySQL connection error:', error);
      res.status(500).json({ error: 'Internal server error' });
      return;
    }
    connection.query('UPDATE categories set name = ?, brand_id = ? where id = ?', [category_name, category_brand,id], (error, results) => {
      connection.release();
      if (error) {
        console.error('MySQL query error:', error);
        res.status(500).json({ error: 'Internal server error' });
      } else if (results.length === 0) {
       res.status(401).json({ error: 'No categories found' });
      } else {
        res.json({ message: "Category has been updated successfully" });
      }
    });
  });
});

router.delete('/delete/:id', (req, res) => {
  id = req.params.id;
  pool.getConnection((error, connection) => {
    if (error) {
      console.error('MySQL connection error:', error);
      res.status(500).json({ error: 'Internal server error' });
      return;
    }
    connection.query('DELETE from categories where id=?', [id], (error, results) => {
      connection.release();
      if (error) {
        console.error('MySQL query error:', error);
        res.status(500).json({ error: 'Internal server error' });
      } else if (results.length === 0) {
       res.status(401).json({ error: 'No categories found' });
      } else {
        res.json({ message: "Category has been deleted successfully" });
      }
    });
  });
});


module.exports = router;