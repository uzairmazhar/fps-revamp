var express = require('express');
var router = express.Router();
const pool = require('../connection');

router.get('/', (req, res) => {
  pool.getConnection((error, connection) => {
    if (error) {
      console.error('MySQL connection error:', error);
      res.status(500).json({ error: 'Internal server error' });
      return;
    }
    connection.query('SELECT * FROM order_lines', (error, results) => {
      connection.release();
      if (error) {
        console.error('MySQL query error:', error);
        res.status(500).json({ error: 'Internal server error' });
      } else if (results.length === 0) {
       res.status(401).json({ error: 'No order lines found' });
      } else {
        res.json({ products: results });
      }
    });
  });
});

router.post('/add', (req, res) => {
  order_id = req.body.order_id;
  product_id = req.body.product_id;
  quantity = req.body.quantity;
  price = req.body.quantity;
  pool.getConnection((error, connection) => {
    if (error) {
      console.error('MySQL connection error:', error);
      res.status(500).json({ error: 'Internal server error' });
      return;
    }
    connection.query('INSERT INTO order_lines(order_id,product_id,quantity,price) VALUES (?,?,?,?)', [order_id, product_id, quantity,price], (error, results) => {
      connection.release();
      if (error) {
        console.error('MySQL query error:', error);
        res.status(500).json({ error: 'Internal server error' });
      } else if (results.length === 0) {
       res.status(401).json({ error: 'No order lines found' });
      } else {
        res.json({ message: "Order line has been added successfully" });
      }
    });
  });
});

router.put('/update/:id', (req, res) => {
  order_id = req.body.order_id;
  product_id = req.body.product_id;
  quantity = req.body.quantity;
  price = req.body.quantity;
  id = req.params.id;
  
  pool.getConnection((error, connection) => {
    if (error) {
      console.error('MySQL connection error:', error);
      res.status(500).json({ error: 'Internal server error' });
      return;
    }
    connection.query('UPDATE order_lines set order_id = ?, product_id = ?, quantity = ?, price = ? where id = ?', [order_id, product_id,quantity,price], (error, results) => {
      connection.release();
      if (error) {
        console.error('MySQL query error:', error);
        res.status(500).json({ error: 'Internal server error' });
      } else if (results.length === 0) {
       res.status(401).json({ error: 'No order lines found' });
      } else {
        res.json({ message: "Order line has been updated successfully" });
      }
    });
  });
});

router.delete('/delete/:id', (req, res) => {
  id = req.params.id;
  pool.getConnection((error, connection) => {
    if (error) {
      console.error('MySQL connection error:', error);
      res.status(500).json({ error: 'Internal server error' });
      return;
    }
    connection.query('DELETE from order_lines where id=?', [id], (error, results) => {
      connection.release();
      if (error) {
        console.error('MySQL query error:', error);
        res.status(500).json({ error: 'Internal server error' });
      } else if (results.length === 0) {
       res.status(401).json({ error: 'No order lines found' });
      } else {
        res.json({ message: "Order line has been deleted successfully" });
      }
    });
  });
});


module.exports = router;