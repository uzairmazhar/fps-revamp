var express = require('express');
var router = express.Router();
const pool = require('../connection');
const util = require('util');

const getConnection = () => {
  return new Promise((resolve, reject) => {
    pool.getConnection((error, connection) => {
      if (error) {
        reject(error);
      } else {
        resolve(connection);
      }
    });
  });
};

router.get('/po/email', async (req, res) => {
  const dbconnection = await getConnection();
  const queryAsync = util.promisify(dbconnection.query).bind(dbconnection);
  
  const productResults = await queryAsync('SELECT name, stock, po_threshold FROM products join product_stock on products.id = product_stock.product_id where product_stock.PO_threshold >= product_stock.stock');
  if (productResults.length == 0) {
  res.json({ message: "No PO was generated!" });
  }
  
  res.json({
  Messge: 'Email has been sent for PO Creation of ',productResults
  });
});


module.exports = router;