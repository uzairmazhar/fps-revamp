var express = require('express');
var router = express.Router();
const pool = require('../connection');

router.get('/', (req, res) => {
    const cart = req.session.cart || [];
    res.status(200).json({ cart_items: cart });  
});

router.post('/add', (req,res)=>{
    const product_id = req.body.product_id;
    const quantity = req.body.quantity;

    const cart = req.session.cart || {}

    req.session.cart.push({
        product_id,quantity
    });
    
    res.json({
        message:"Product has been added in the cart",
    });
});

router.post('/cart/add', (req, res) => {
    const product_id = req.body.product_id; 
    const quantity = req.body.quantity;
  
    req.session.cart = req.session.cart || [];
  
    req.session.cart.push({ product_id, quantity });
  
    res.status(200).json({ message: 'Item added to cart' });
  });
  

module.exports = router;