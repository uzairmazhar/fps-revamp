var express = require('express');
var router = express.Router();
const pool = require('../connection');

router.get('/', (req, res) => {
  pool.getConnection((error, connection) => {
    if (error) {
      console.error('MySQL connection error:', error);
      res.status(500).json({ error: 'Internal server error' });
      return;
    }
    connection.query('SELECT * FROM departments', (error, results) => {
      connection.release();
      if (error) {
        console.error('MySQL query error:', error);
        res.status(500).json({ error: 'Internal server error' });
      } else if (results.length === 0) {
       res.status(401).json({ error: 'No departments found' });
      } else {
        res.json({ products: results });
      }
    });
  });
});

router.post('/add', (req, res) => {
  department_name = req.body.department_name;
  bu_id = req.body.bu_id;
  pool.getConnection((error, connection) => {
    if (error) {
      console.error('MySQL connection error:', error);
      res.status(500).json({ error: 'Internal server error' });
      return;
    }
    connection.query('INSERT INTO departments(name,bu_id) VALUES (?,?)', [department_name, bu_id], (error, results) => {
      connection.release();
      if (error) {
        console.error('MySQL query error:', error);
        res.status(500).json({ error: 'Internal server error' });
      } else if (results.length === 0) {
       res.status(401).json({ error: 'No departments found' });
      } else {
        res.json({ message: "Departments has been added successfully" });
      }
    });
  });
});

router.put('/update/:id', (req, res) => {
  department_name = req.body.department_name;
  bu_id = req.body.bu_id;
  id = req.params.id;
  
  pool.getConnection((error, connection) => {
    if (error) {
      console.error('MySQL connection error:', error);
      res.status(500).json({ error: 'Internal server error' });
      return;
    }
    connection.query('UPDATE departments set name = ?, bu_id = ? where id = ?', [department_name, bu_id,id], (error, results) => {
      connection.release();
      if (error) {
        console.error('MySQL query error:', error);
        res.status(500).json({ error: 'Internal server error' });
      } else if (results.length === 0) {
       res.status(401).json({ error: 'No department found' });
      } else {
        res.json({ message: "Department has been updated successfully" });
      }
    });
  });
});

router.delete('/delete/:id', (req, res) => {
  id = req.params.id;
  pool.getConnection((error, connection) => {
    if (error) {
      console.error('MySQL connection error:', error);
      res.status(500).json({ error: 'Internal server error' });
      return;
    }
    connection.query('DELETE from departments where id=?', [id], (error, results) => {
      connection.release();
      if (error) {
        console.error('MySQL query error:', error);
        res.status(500).json({ error: 'Internal server error' });
      } else if (results.length === 0) {
       res.status(401).json({ error: 'No department found' });
      } else {
        res.json({ message: "Department has been deleted successfully" });
      }
    });
  });
});


module.exports = router;