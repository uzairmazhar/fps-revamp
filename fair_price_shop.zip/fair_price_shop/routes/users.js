const express = require('express');
const jwt = require('jsonwebtoken');
const router = express.Router();
const config = require('../config');

const authenticateToken = require('../authMiddleware');

// Import the pool
const pool = require('../connection');

/* GET users listing. */
router.get('/', authenticateToken,function(req, res, next) {
  res.json({message:'You are authenticated'});
});


router.post('/login',(req, res) => {
  const username = req.body.username;
  const password = req.body.password;
  const user = {name:username}
  // const { username, password } = req.body;

  pool.getConnection((error, connection) => {
    if (error) {
      console.error('MySQL connection error:', error);
      res.status(500).json({ error: 'Internal server error' });
      return;
    }

    connection.query(
      'SELECT * FROM users WHERE username = ? AND password = MD5(?)',
      [username, password],
      (error, results) => {
        connection.release();
        if (error) {
          console.error('MySQL query error:', error);
          res.status(500).json({ error: 'Internal server error' });
        } else if (results.length === 0) {
          res.status(401).json({ error: 'Invalid username or password' });
        } else {
          const token = jwt.sign(user, config.secretKey);
          res.json({ 
              message: 'Login successful',
              token: token, 
            });
        }
      }
    );
  });
});

module.exports = router;