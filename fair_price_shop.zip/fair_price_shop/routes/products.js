var express = require('express');
var router = express.Router();
const pool = require('../connection');

router.get('/', (req, res) => {
  pool.getConnection((error, connection) => {
    if (error) {
      console.error('MySQL connection error:', error);
      res.status(500).json({ error: 'Internal server error' });
      return;
    }
    connection.query('SELECT * FROM products', (error, results) => {
      connection.release();
      if (error) {
        console.error('MySQL query error:', error);
        res.status(500).json({ error: 'Internal server error' });
      } else if (results.length === 0) {
       res.status(401).json({ error: 'No products found' });
      } else {
        res.json({ products: results });
      }
    });
  });
});

router.post('/add', (req, res) => {
  product_name = req.body.product_name;
  product_sku = req.body.product_sku;
  product_image = req.body.product_image;
  product_category = req.body.product_category;
  product_price = req.body.product_price;
  pool.getConnection((error, connection) => {
    if (error) {
      console.error('MySQL connection error:', error);
      res.status(500).json({ error: 'Internal server error' });
      return;
    }
    connection.query('INSERT INTO products(name, sku, image, price, category_id) VALUES (?,?,?,?,?)', [product_name,product_sku,product_image,product_price,product_category], (error, results) => {
      connection.release();
      if (error) {
        console.error('MySQL query error:', error);
        res.status(500).json({ error: 'Internal server error' });
      } else if (results.length === 0) {
       res.status(401).json({ error: 'No products found' });
      } else {
        res.json({ message: "Product has been added successfully" });
      }
    });
  });
});

router.put('/update/:id', (req, res) => {
  product_name = req.body.product_name;
  product_sku = req.body.product_sku;
  product_image = req.body.product_image;
  product_category = req.body.product_category;
  product_price = req.body.product_price;

  id = req.params.id;
  
  pool.getConnection((error, connection) => {
    if (error) {
      console.error('MySQL connection error:', error);
      res.status(500).json({ error: 'Internal server error' });
      return;
    }
    connection.query('UPDATE products set name = ?, sku = ?, image = ?, price = ?, category_id = ? where id=?', [product_name,product_sku,product_image,product_price,product_category,id], (error, results) => {
      connection.release();
      if (error) {
        console.error('MySQL query error:', error);
        res.status(500).json({ error: 'Internal server error' });
      } else if (results.length === 0) {
       res.status(401).json({ error: 'No products found' });
      } else {
        res.json({ message: "Product has been updated successfully" });
      }
    });
  });
});

router.delete('/delete/:id', (req, res) => {
  id = req.params.id;
  pool.getConnection((error, connection) => {
    if (error) {
      console.error('MySQL connection error:', error);
      res.status(500).json({ error: 'Internal server error' });
      return;
    }
    connection.query('DELETE from products where id=?', [id], (error, results) => {
      connection.release();
      if (error) {
        console.error('MySQL query error:', error);
        res.status(500).json({ error: 'Internal server error' });
      } else if (results.length === 0) {
       res.status(401).json({ error: 'No products found' });
      } else {
        res.json({ message: "Product has been deleted successfully" });
      }
    });
  });
});


module.exports = router;